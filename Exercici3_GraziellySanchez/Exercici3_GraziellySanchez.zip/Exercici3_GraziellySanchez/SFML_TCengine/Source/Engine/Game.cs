﻿namespace TCEngine
{
    public interface Game
    {
        void Init();
        void DeInit();
        void Update(float _dt);
    }
}
